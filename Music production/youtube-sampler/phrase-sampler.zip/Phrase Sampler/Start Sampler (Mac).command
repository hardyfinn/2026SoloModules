#!/bin/bash
# Double-click to start Phrase Sampler on a Mac.
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:$PATH"
if ! command -v uv >/dev/null 2>&1; then
  echo "First run: installing the 'uv' helper that sets up Python for you (one time only)..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi
echo "Starting Phrase Sampler (the first start takes a minute while it downloads its parts)..."
uv run --upgrade-package yt-dlp sampler.py
