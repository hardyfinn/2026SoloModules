# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "yt-dlp[default]",
#   "imageio-ffmpeg",
#   "deno",
# ]
# ///
"""
Phrase Sampler: search YouTube for a spoken word or phrase and grab just
that bit of audio as a WAV.

How it works
1. Ask YouTube for videos (a normal search, or a channel/playlist/video link).
2. Read each video's captions, which carry word-by-word timings.
3. Find the phrase in the captions and note when it is spoken.
4. On Play or Download, fetch only a few seconds of audio around that moment
   and trim it to a WAV with tiny fades so it drops straight into Live.

Run it with the "Start Sampler" launcher next to this file.
"""

import glob
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

import imageio_ffmpeg
import yt_dlp

APP_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLES_DIR = os.path.join(APP_DIR, "Samples")
CACHE_DIR = os.path.join(APP_DIR, ".cache")
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
PORT = 8765

import shutil
from yt_dlp.postprocessor.ffmpeg import FFmpegPostProcessor


def setup_ffmpeg():
    """Copy the bundled ffmpeg into .bin/ under its plain name and put it on PATH.
    yt-dlp's partial-download check only looks for a program called "ffmpeg"."""
    bundled = imageio_ffmpeg.get_ffmpeg_exe()
    bin_dir = os.path.join(APP_DIR, ".bin")
    os.makedirs(bin_dir, exist_ok=True)
    target = os.path.join(bin_dir, "ffmpeg.exe" if sys.platform.startswith("win") else "ffmpeg")
    if not os.path.exists(target) or os.path.getsize(target) != os.path.getsize(bundled):
        shutil.copyfile(bundled, target)
        os.chmod(target, 0o755)
    os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
    return target


FFMPEG = setup_ffmpeg()
try:
    from deno import find_deno_bin
    JS_RUNTIMES = {"deno": {"path": os.fsdecode(find_deno_bin())}}
except Exception:
    JS_RUNTIMES = {"deno": {}}

os.makedirs(SAMPLES_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)
for _old in glob.glob(os.path.join(CACHE_DIR, "*")):
    if time.time() - os.path.getmtime(_old) > 7 * 86400:  # tidy week-old audio
        try:
            os.remove(_old)
        except OSError:
            pass


# ---------------------------------------------------------------- settings

DEFAULT_SETTINGS = {"cookies_browser": "", "sample_rate": 44100}


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return {**DEFAULT_SETTINGS, **json.load(f)}
    except Exception:
        return dict(DEFAULT_SETTINGS)


def save_settings(s):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2)


SETTINGS = load_settings()


def ydl_opts(**extra):
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "ffmpeg_location": FFMPEG,
        "js_runtimes": JS_RUNTIMES,
    }
    if SETTINGS.get("cookies_browser"):
        opts["cookiesfrombrowser"] = (SETTINGS["cookies_browser"],)
    opts.update(extra)
    return opts


# ---------------------------------------------------------------- captions

def normalise(word):
    word = word.lower().replace("’", "'")
    return re.sub(r"[^a-z0-9À-ɏЀ-ӿ]+", "", word)


def pick_caption_track(info, lang):
    """Return (json3 url, kind) for the spoken-language captions, or (None, None).
    Avoids machine-translated tracks, whose timings don't match the voice."""
    def json3(tracks):
        for t in tracks or []:
            if t.get("ext") == "json3":
                return t.get("url")
        return None

    subs = info.get("subtitles") or {}
    for key in [lang] + sorted(k for k in subs if k.split("-")[0] == lang and k != lang):
        url = json3(subs.get(key))
        if url:
            return url, "manual"

    auto = info.get("automatic_captions") or {}
    originals = [k for k in auto if k.endswith("-orig")]
    if originals:
        url = json3(auto.get(f"{lang}-orig"))
        return (url, "auto") if url else (None, None)
    spoken = (info.get("language") or lang).split("-")[0]
    if spoken == lang:
        url = json3(auto.get(lang))
        if url:
            return url, "auto"
    return None, None


def parse_json3(data):
    """Turn YouTube json3 captions into a list of words with start/end in seconds."""
    events = [e for e in data.get("events", [])
              if any(s.get("utf8", "").strip() for s in e.get("segs") or [])]
    words = []
    for i, ev in enumerate(events):
        ev_start = ev.get("tStartMs", 0)
        ev_end = ev_start + ev.get("dDurationMs", 0)
        if i + 1 < len(events):
            ev_end = min(ev_end, events[i + 1].get("tStartMs", ev_end)) or ev_end
        segs = [s for s in ev["segs"] if s.get("utf8", "").strip()]
        if not segs:
            continue
        timed = any("tOffsetMs" in s for s in segs[1:])
        if timed:
            # auto captions: each seg is a word with its own offset
            pieces = [(ev_start + s.get("tOffsetMs", 0), s["utf8"]) for s in segs]
        else:
            # manual captions: one line of text, spread words evenly over it
            text = " ".join(s["utf8"] for s in segs).split()
            span = max(ev_end - ev_start, 1)
            pieces = [(ev_start + span * k / len(text), w) for k, w in enumerate(text)]
        for k, (t, raw) in enumerate(pieces):
            for sub in raw.split():
                # last word of a line: the line's end can include a pause, so cap it
                end = pieces[k + 1][0] if k + 1 < len(pieces) else min(ev_end, t + 900)
                n = normalise(sub)
                if n:
                    words.append({"w": n, "raw": sub, "start": t / 1000, "end": max(end, t + 150) / 1000})
    return words


def find_phrase(words, phrase):
    target = [normalise(w) for w in phrase.split() if normalise(w)]
    hits = []
    if not target:
        return hits
    n = len(target)
    for i in range(len(words) - n + 1):
        if all(words[i + j]["w"] == target[j] for j in range(n)):
            before = " ".join(w["raw"] for w in words[max(0, i - 7):i])
            match = " ".join(w["raw"] for w in words[i:i + n])
            after = " ".join(w["raw"] for w in words[i + n:i + n + 7])
            hits.append({
                "start": round(words[i]["start"], 3),
                "end": round(words[i + n - 1]["end"], 3),
                "before": before, "match": match, "after": after,
            })
    return hits


# ---------------------------------------------------------------- search jobs

JOBS = {}


def list_videos(source, max_videos):
    source = source.strip()
    if re.match(r"https?://", source):
        target = source
    else:
        target = f"ytsearch{max_videos}:{source}"
    with yt_dlp.YoutubeDL(ydl_opts(extract_flat="in_playlist", playlistend=max_videos)) as ydl:
        info = ydl.extract_info(target, download=False)
    entries = info.get("entries") if info.get("_type") in ("playlist", "multi_video") else [info]
    vids = []
    for e in entries or []:
        if not e:
            continue
        if e.get("_type") == "playlist" and e.get("entries") is None:
            continue  # e.g. a channel's "Shorts" tab heading
        vid = e.get("id")
        if vid and len(vid) == 11:
            vids.append({"id": vid, "title": e.get("title") or vid,
                         "channel": e.get("channel") or e.get("uploader") or ""})
        if len(vids) >= max_videos:
            break
    return vids


def scan_video(job, video):
    if job["cancel"]:
        return
    url = f"https://www.youtube.com/watch?v={video['id']}"
    try:
        with yt_dlp.YoutubeDL(ydl_opts(skip_download=True, extractor_args={"youtube": {"skip": ["hls"]}})) as ydl:
            info = ydl.extract_info(url, download=False)
            sub_url, kind = pick_caption_track(info, job["lang"])
            if not sub_url:
                job["no_captions"] += 1
                return
            data = json.loads(ydl.urlopen(sub_url).read().decode("utf-8"))
        hits = find_phrase(parse_json3(data), job["phrase"])
        for h in hits:
            job["results"].append({
                **h, "id": video["id"], "kind": kind,
                "title": info.get("title") or video["title"],
                "channel": info.get("channel") or info.get("uploader") or video["channel"],
            })
    except Exception as e:
        msg = str(e).replace("\n", " ")
        job["errors"].append(f"{video['title'][:60]}: {msg[:200]}")
    finally:
        job["scanned"] += 1


def run_job(job):
    try:
        job["status"] = "Finding videos"
        videos = list_videos(job["source"], job["max_videos"])
        job["total"] = len(videos)
        job["status"] = "Reading captions"
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda v: scan_video(job, v), videos))
        job["status"] = "Stopped" if job["cancel"] else "Done"
    except Exception as e:
        job["status"] = "Failed"
        job["errors"].append(str(e).replace("\n", " ")[:300])
    job["finished"] = True


def start_job(params):
    phrase = params.get("phrase", "").strip()
    source = params.get("source", "").strip() or phrase
    job = {
        "id": uuid.uuid4().hex[:10], "phrase": phrase, "source": source,
        "lang": params.get("lang", "en").strip().lower() or "en",
        "max_videos": max(1, min(int(params.get("max_videos", 20)), 100)),
        "status": "Starting", "total": 0, "scanned": 0, "no_captions": 0,
        "results": [], "errors": [], "finished": False, "cancel": False,
    }
    JOBS[job["id"]] = job
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return job["id"]


# ---------------------------------------------------------------- audio clips

CLIP_LOCKS = {}
RECENT_ERRORS = {}  # (video, start, end) -> (time, message)
CACHE_INDEX = {}  # video id -> list of (window_start, window_end, path)


def media_duration(path):
    """Length of an audio file in seconds (0 if ffmpeg can't read it)."""
    out = subprocess.run([FFMPEG, "-hide_banner", "-i", path], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", out)
    return int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3]) if m else 0.0


FULL_AUDIO_LIMIT = 90 * 60  # videos up to this long are downloaded whole (once)


def download_audio(vid, stem, section=None, max_length=None):
    """Download a video's whole audio track, or just `section` (start, end) of it.
    With max_length, gives up (returns None) on videos longer than that."""
    opts = ydl_opts(
        format="bestaudio/best",
        outtmpl=stem + ".%(ext)s",
        overwrites=True,
        socket_timeout=20,
        retries=3,
        http_chunk_size=10 * 1024 * 1024,  # small requests, so YouTube doesn't slow us down
    )
    FFmpegPostProcessor._ffmpeg_location.set(FFMPEG)  # per-thread setting yt-dlp checks
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False)
        if max_length and (info.get("duration") or 0) > max_length:
            return None
        if not section:
            ydl.process_ie_result(info, download=True)
    if section:
        # read just the slice straight from YouTube's audio stream, decoding as we go
        # so the file starts exactly at section[0]
        fmt = (info.get("requested_formats") or [info])[0]
        headers = "".join(f"{k}: {v}\r\n" for k, v in (fmt.get("http_headers") or {}).items())
        out = stem + ".wav"
        cmd = [FFMPEG, "-y", "-loglevel", "error", "-rw_timeout", "20000000"]
        if headers:
            cmd += ["-headers", headers]
        cmd += ["-ss", f"{section[0]:.3f}", "-t", f"{section[1] - section[0]:.3f}", "-i", fmt["url"],
                "-vn", "-c:a", "pcm_s16le", out]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode:
            raise RuntimeError(res.stderr.strip()[-300:])
        return out if media_duration(out) > 0 else None
    files = [f for f in glob.glob(stem + ".*") if not f.endswith((".part", ".ytdl"))]
    return files[0] if files and media_duration(files[0]) > 0 else None


def fetch_window(vid, start, end, avoid=None):
    """Get audio covering [start, end], reusing earlier downloads.
    Normal videos: the whole audio track once, so every hit in it is instant.
    Very long videos: just a few seconds around the phrase.
    Returns (time in the video where the file starts, file path)."""
    for ws, we, path in CACHE_INDEX.get(vid, []):
        if ws <= start and we >= end and os.path.exists(path) and path != avoid:
            return ws, path
    problems = []
    if avoid is None or "_full" not in avoid:
        try:
            log("  downloading this video's audio (once per video)...")
            path = download_audio(vid, os.path.join(CACHE_DIR, f"{vid}_full"), max_length=FULL_AUDIO_LIMIT)
            if path:
                CACHE_INDEX.setdefault(vid, []).append((0.0, 1e9, path))
                return 0.0, path
            log("  long video, fetching just the slice instead")
        except Exception as e:
            problems.append(str(e))
            log(f"  full download didn't work ({str(e)[:150]}), trying just the slice")
    ws, we = max(0.0, start - 3.0), end + 3.0
    try:
        path = download_audio(vid, os.path.join(CACHE_DIR, f"{vid}_{int(ws * 1000)}_{int(we * 1000)}"), (ws, we))
        if path:
            CACHE_INDEX.setdefault(vid, []).append((ws, we, path))
            return ws, path
    except Exception as e:
        problems.append(str(e))
    raise RuntimeError("YouTube didn't send any audio for this video. " + " / ".join(problems)[:300])


def peak_db(path):
    out = subprocess.run([FFMPEG, "-hide_banner", "-i", path, "-af", "volumedetect", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    m = re.search(r"max_volume: (-?[\d.]+|-inf) dB", out)
    return -999.0 if not m or m[1] == "-inf" else float(m[1])


def make_clip(vid, start, end):
    """Return the path of a trimmed WAV for this video and time range."""
    key = f"{vid}_{start:.3f}_{end:.3f}_{SETTINGS['sample_rate']}"
    out = os.path.join(CACHE_DIR, hashlib.md5(key.encode()).hexdigest() + ".wav")
    lock = CLIP_LOCKS.setdefault(vid, threading.Lock())
    with lock:
        if os.path.exists(out):
            return out
        avoid = None
        for attempt in range(2):
            ws, src = fetch_window(vid, start, end, avoid)
            dur = max(0.05, end - start)
            fade = min(0.008, dur / 4)
            # seek on the input so the clip's own clock starts at 0, which the fades rely on
            cmd = [FFMPEG, "-y", "-loglevel", "error",
                   "-ss", f"{start - ws:.3f}", "-t", f"{dur:.3f}", "-i", src,
                   "-af", f"asetpts=PTS-STARTPTS,afade=t=in:d={fade},afade=t=out:st={dur - fade:.3f}:d={fade}",
                   "-ar", str(SETTINGS["sample_rate"]), "-ac", "2", "-c:a", "pcm_s16le", out]
            res = subprocess.run(cmd, capture_output=True, text=True)
            ok = not res.returncode and os.path.exists(out) and os.path.getsize(out) > 1000
            if ok and peak_db(out) > -60:
                break
            # empty or silent: the downloaded audio was probably wrong, so get it a different way
            log("  that clip came out " + ("silent" if ok else "empty") + ", trying another download")
            if os.path.exists(out):
                os.remove(out)
            CACHE_INDEX[vid] = [w for w in CACHE_INDEX.get(vid, []) if w[2] != src]
            avoid = src
        else:
            if ok:
                raise RuntimeError("This bit of the video is silent, so the captions' timing may be off. "
                                   "Try 'open on YouTube' to hear where the words really are.")
            raise RuntimeError("Couldn't cut the clip: " + (res.stderr.strip()[-300:] or "the audio came back empty"))
    return out


def log(msg):
    try:
        print(time.strftime("%H:%M:%S ") + msg, flush=True)
    except Exception:
        pass


def slug(text, n=40):
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-")[:n].strip("-") or "clip"


def open_folder(path):
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# ---------------------------------------------------------------- web server

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == "/":
            body = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif u.path.startswith("/api/job/"):
            job = JOBS.get(u.path.rsplit("/", 1)[-1])
            if not job:
                return self.send_json({"error": "unknown job"}, 404)
            self.send_json({k: v for k, v in job.items() if k != "cancel"})
        elif u.path == "/api/settings":
            self.send_json({**SETTINGS, "samples_dir": SAMPLES_DIR})
        elif u.path == "/api/clip":
            self.serve_clip(q)
        else:
            self.send_error(404)

    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/api/search":
            self.send_json({"job": start_job(self.read_json())})
        elif u.path.startswith("/api/cancel/"):
            job = JOBS.get(u.path.rsplit("/", 1)[-1])
            if job:
                job["cancel"] = True
            self.send_json({"ok": True})
        elif u.path == "/api/settings":
            data = self.read_json()
            SETTINGS["cookies_browser"] = data.get("cookies_browser", "")
            SETTINGS["sample_rate"] = int(data.get("sample_rate", 44100))
            save_settings(SETTINGS)
            self.send_json({"ok": True})
        elif u.path == "/api/open-samples":
            open_folder(SAMPLES_DIR)
            self.send_json({"ok": True})
        else:
            self.send_error(404)

    def serve_clip(self, q):
        try:
            vid = q["vid"]
            if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
                raise ValueError("bad video id")
            start, end = max(0.0, float(q["start"])), float(q["end"])
            if not 0 < end - start <= 60:
                raise ValueError("Clips must be between 0 and 60 seconds long.")
            recent = RECENT_ERRORS.get((vid, start, end))
            if recent and time.time() - recent[0] < 30:
                raise RuntimeError(recent[1])  # the page re-asks to read the error; don't redo the work
            t0 = time.time()
            log(f"Getting audio: {q.get('title', vid)[:60]} at {int(start // 60)}:{start % 60:05.2f}")
            path = make_clip(vid, start, end)
            log(f"  ready in {time.time() - t0:.1f}s")
        except Exception as e:
            log(f"  PROBLEM: {e}")
            if "t0" in locals():
                RECENT_ERRORS[(vid, start, end)] = (time.time(), str(e))
            return self.send_json({"error": str(e).replace("\n", " ")[:400]}, 500)
        headers = {"Content-Type": "audio/wav"}
        if q.get("download"):
            name = f"{slug(q.get('phrase', 'phrase'), 30)}_{slug(q.get('title', vid))}_{int(start // 60)}m{start % 60:04.1f}s.wav"
            saved = os.path.join(SAMPLES_DIR, name)
            with open(path, "rb") as src, open(saved, "wb") as dst:
                dst.write(src.read())
            headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{quote(name)}"
        with open(path, "rb") as f:
            body = f.read()
        # Safari only plays audio from servers that can send byte ranges
        code, rng = 200, re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range") or "")
        if rng and not q.get("download"):
            first = int(rng[1]) if rng[1] else max(0, len(body) - int(rng[2] or 0))
            last = min(int(rng[2]), len(body) - 1) if rng[1] and rng[2] else len(body) - 1
            headers["Content-Range"] = f"bytes {first}-{last}/{len(body)}"
            body, code = body[first:last + 1], 206
        self.send_response(code)
        for k, v in headers.items():
            self.send_header(k, v)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Phrase Sampler</title>
<style>
:root{--bg:#111214;--panel:#1b1d21;--line:#2c2f35;--text:#e8e8ea;--dim:#9a9ca3;--acc:#ff8a3d;--ok:#5fd38d}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.45 system-ui,-apple-system,Segoe UI,sans-serif}
header{padding:20px 24px 8px}
h1{margin:0;font-size:22px;letter-spacing:.3px}
h1 span{color:var(--acc)}
.sub{color:var(--dim);font-size:13px;margin-top:2px}
form{display:grid;grid-template-columns:2fr 2fr 70px 90px auto;gap:10px;padding:14px 24px;align-items:end}
label{display:block;font-size:12px;color:var(--dim);margin-bottom:4px}
input,select{width:100%;background:var(--panel);border:1px solid var(--line);color:var(--text);padding:9px 10px;border-radius:7px;font:inherit}
input:focus{outline:none;border-color:var(--acc)}
button{background:var(--panel);border:1px solid var(--line);color:var(--text);padding:8px 12px;border-radius:7px;font:inherit;cursor:pointer;white-space:nowrap}
button:hover{border-color:var(--acc)}
button.primary{background:var(--acc);border-color:var(--acc);color:#111;font-weight:600;padding:9px 18px}
.bar{display:flex;gap:16px;align-items:center;padding:0 24px 10px;color:var(--dim);font-size:13px;flex-wrap:wrap}
.bar .pad{display:flex;gap:6px;align-items:center}
.bar .pad input{width:64px;padding:5px 7px}
#status{padding:4px 24px 10px;color:var(--dim);font-size:13px}
#results{padding:0 24px 40px;display:grid;gap:10px}
.card{display:grid;grid-template-columns:120px 1fr;gap:14px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px}
.card img{width:120px;height:68px;object-fit:cover;border-radius:6px;background:#000}
.title{font-weight:600;font-size:14px}
.meta{color:var(--dim);font-size:12px}
.snip{margin:6px 0;font-size:14px}
.snip b{color:var(--acc);font-weight:600}
.ctl{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.ctl button{padding:5px 9px;font-size:13px}
.ctl .t{font-variant-numeric:tabular-nums;color:var(--dim);font-size:12px;min-width:120px}
.ctl a{color:var(--dim);font-size:12px}
.busy{opacity:.6;pointer-events:none}
.err{color:#ff9070;font-size:13px;font-weight:600}
details{padding:0 24px;color:var(--dim);font-size:12px}
@media(max-width:820px){form{grid-template-columns:1fr 1fr}.card{grid-template-columns:1fr}}
</style></head><body>
<header><h1>Phrase <span>Sampler</span></h1>
<div class="sub">Find a spoken word or phrase on YouTube and grab just that slice of audio.</div></header>
<form id="f">
  <div><label>Spoken phrase to find</label><input id="phrase" placeholder="e.g. the future" required></div>
  <div><label>Search YouTube for (optional: topic words or a channel / playlist / video link)</label><input id="source" placeholder="leave blank to search for the phrase itself"></div>
  <div><label>Language</label><input id="lang" value="en"></div>
  <div><label>Videos to scan</label><input id="max" type="number" value="20" min="1" max="100"></div>
  <div><button class="primary" id="go">Search</button></div>
</form>
<div class="bar">
  <span class="pad">Pad before <input id="pre" type="number" step="0.05" value="0.15">s</span>
  <span class="pad">after <input id="post" type="number" step="0.05" value="0.25">s</span>
  <button type="button" id="stop" hidden>Stop</button>
  <button type="button" id="openf">Open Samples folder</button>
  <span class="pad">YouTube sign-in from
    <select id="cookies"><option value="">(none)</option><option>chrome</option><option>firefox</option><option>edge</option><option>safari</option><option>brave</option></select></span>
</div>
<div id="status">Type a phrase and press Search.</div>
<div id="results"></div>
<details id="errs" hidden><summary>Videos that couldn't be read</summary><div id="errlist"></div></details>
<script>
const $ = s => document.querySelector(s);
let job = null, shown = 0, timer = null, player = new Audio(), stopLoading = () => {};
const fmt = t => { const m = Math.floor(t/60), s = (t%60).toFixed(2).padStart(5,'0'); return m+':'+s; };
const esc = s => s.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

fetch('/api/settings').then(r=>r.json()).then(s=>{ $('#cookies').value = s.cookies_browser||''; });
$('#cookies').onchange = () => fetch('/api/settings',{method:'POST',body:JSON.stringify({cookies_browser:$('#cookies').value})});
$('#openf').onclick = () => fetch('/api/open-samples',{method:'POST'});
$('#stop').onclick = () => job && fetch('/api/cancel/'+job,{method:'POST'});

$('#f').onsubmit = async e => {
  e.preventDefault();
  clearInterval(timer); $('#results').innerHTML=''; $('#errlist').innerHTML=''; $('#errs').hidden=true; shown=0;
  const r = await fetch('/api/search',{method:'POST',body:JSON.stringify({
    phrase:$('#phrase').value, source:$('#source').value, lang:$('#lang').value, max_videos:$('#max').value})});
  job = (await r.json()).job; $('#stop').hidden=false;
  timer = setInterval(poll, 800); poll();
};

async function poll(){
  const j = await (await fetch('/api/job/'+job)).json();
  while (shown < j.results.length) addCard(j.results[shown++], j.phrase);
  let s = `${j.status}: ${j.scanned}/${j.total||'?'} videos checked, ${j.results.length} matches`;
  if (j.no_captions) s += `, ${j.no_captions} had no captions in that language`;
  $('#status').textContent = s;
  if (j.errors.length){ $('#errs').hidden=false; $('#errlist').innerHTML = j.errors.map(x=>'<div>'+esc(x)+'</div>').join(''); }
  if (j.finished){ clearInterval(timer); $('#stop').hidden=true;
    if (!j.results.length && j.status==='Done') $('#status').textContent += '. Try more videos, or add topic words like "interview" or "speech".'; }
}

function addCard(r, phrase){
  const pre = parseFloat($('#pre').value)||0, post = parseFloat($('#post').value)||0;
  const c = {start: Math.max(0, r.start - pre), end: r.end + post};
  const el = document.createElement('div'); el.className='card';
  el.innerHTML = `<img src="https://i.ytimg.com/vi/${r.id}/mqdefault.jpg" loading="lazy">
   <div><div class="title">${esc(r.title)}</div>
   <div class="meta">${esc(r.channel)} · ${r.kind==='manual'?'human captions':'auto captions'}</div>
   <div class="snip">…${esc(r.before)} <b>${esc(r.match)}</b> ${esc(r.after)}…</div>
   <div class="ctl">
     <button data-a="play">▶ Play</button>
     <button data-a="s-" title="start earlier">⟸ start</button><button data-a="s+" title="start later">start ⟹</button>
     <button data-a="e-" title="end earlier">⟸ end</button><button data-a="e+" title="end later">end ⟹</button>
     <span class="t"></span>
     <button data-a="dl">⬇ WAV</button>
     <a target="_blank" href="https://www.youtube.com/watch?v=${r.id}&t=${Math.floor(r.start)}s">open on YouTube</a>
     <span class="err"></span>
   </div></div>`;
  const t = el.querySelector('.t'), err = el.querySelector('.err');
  const show = () => t.textContent = `${fmt(c.start)} → ${fmt(c.end)} (${(c.end-c.start).toFixed(2)}s)`;
  show();
  const url = dl => `/api/clip?vid=${r.id}&start=${c.start.toFixed(3)}&end=${c.end.toFixed(3)}&title=${encodeURIComponent(r.title)}` +
     (dl ? `&download=1&phrase=${encodeURIComponent(phrase)}` : '');
  const btn = el.querySelector('[data-a=play]');
  const play = () => {
    // start playback straight from the click, so browsers don't block the sound
    player.pause(); stopLoading(); err.textContent = '';
    btn.textContent = '⏳ Loading…'; btn.classList.add('busy');
    const t0 = Date.now(), tick = setInterval(() => btn.textContent = `⏳ Loading… ${Math.round((Date.now()-t0)/1000)}s`, 1000);
    const done = () => { clearInterval(tick); btn.textContent = '▶ Play'; btn.classList.remove('busy'); };
    stopLoading = done;
    const a = new Audio(); player = a;
    a.onplaying = done;
    a.onerror = async () => {
      if (player !== a) return;
      done();
      try { const j = await (await fetch(url(false))).json(); err.textContent = '⚠ ' + (j.error || 'Could not play this clip.'); }
      catch (x) { err.textContent = '⚠ Could not play this clip. The black window shows the details.'; }
    };
    a.src = url(false);
    a.play().catch(x => { if (x.name === 'NotAllowedError') { done(); err.textContent = '⚠ The browser blocked the sound. Click Play again.'; } });
  };
  el.querySelector('.ctl').onclick = e => {
    const a = e.target.dataset.a; if (!a) return;
    const step = 0.1;
    if (a==='play') return play();
    if (a==='dl'){ const l=document.createElement('a'); l.href=url(true); l.click(); err.textContent='saved to Samples folder'; return; }
    if (a==='s-') c.start = Math.max(0, c.start-step);
    if (a==='s+') c.start = Math.min(c.end-0.05, c.start+step);
    if (a==='e-') c.end = Math.max(c.start+0.05, c.end-step);
    if (a==='e+') c.end = c.end+step;
    show(); play();
  };
  $('#results').appendChild(el);
}
</script></body></html>
"""


def main():
    port = PORT
    while True:
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            port += 1
    url = f"http://127.0.0.1:{port}/"
    print("\n  Phrase Sampler is running.")
    print(f"  Your browser should open by itself. If not, go to: {url}")
    print(f"  Downloaded samples are saved in: {SAMPLES_DIR}")
    print("  To quit, close this window.\n")
    if "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
