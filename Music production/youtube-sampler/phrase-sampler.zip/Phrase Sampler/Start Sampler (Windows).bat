@echo off
rem Double-click to start Phrase Sampler on Windows.
cd /d "%~dp0"
set "PATH=%USERPROFILE%\.local\bin;%PATH%"
where uv >nul 2>nul
if errorlevel 1 (
  echo First run: installing the uv helper that sets up Python for you, one time only...
  powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
)
echo Starting Phrase Sampler. The first start takes a minute while it downloads its parts...
uv run --upgrade-package yt-dlp sampler.py
pause
