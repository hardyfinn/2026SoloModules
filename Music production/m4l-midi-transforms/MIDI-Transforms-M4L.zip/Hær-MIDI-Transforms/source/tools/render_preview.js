// Draws a preview PNG of each device: the real brain/display script, fed a real learned
// drum bar and run for a few bars, next to a drawing of the controls (positions from the .maxpat).
//   node tools/render_preview.js            writes previews/<Device>.png
"use strict";
const fs = require("fs"), path = require("path");
const { chromium } = require("playwright");
const ROOT = path.join(__dirname, "..");
const CORE = fs.readFileSync(path.join(ROOT, "src", "transform_core.js"), "utf8");
fs.mkdirSync(path.join(ROOT, "previews"), { recursive: true });

const DEV = [
  { name: "Mutator", kind: "mutator", setup: "everyset(0); hold(0);", bars: 6 },
  { name: "EuclidMorph", kind: "euclid", setup: "morph(70);", bars: 2, set: { Morph: 70 } },
  { name: "MarkovRemix", kind: "markov", setup: "strictness(60); newevery(0);", bars: 4 },
];

function controls(name, set) {
  const p = JSON.parse(fs.readFileSync(path.join(ROOT, "dist", name + ".maxpat"))).patcher;
  let h = "";
  for (const { box: b } of p.boxes) {
    if (!b.presentation || b.maxclass === "jsui") continue;
    const [x, y, w, hh] = b.presentation_rect;
    const st = `left:${x}px;top:${y}px;width:${w}px;height:${hh}px;`;
    const fs_ = (b.fontsize || 10) + "px";
    const v = b.saved_attribute_attributes && b.saved_attribute_attributes.valueof;
    if (b.maxclass === "comment") h += `<div class="a lbl" style="${st}font-size:${fs_}">${b.text}</div>`;
    else if (b.maxclass === "live.text") {
      const on = b.mode === 1 && v.parameter_initial && v.parameter_initial[0] === 1;
      h += `<div class="a btn${on ? " on" : ""}" style="${st}font-size:${fs_}">${b.text}</div>`;
    } else if (b.maxclass === "live.tab") {
      const d = v.parameter_initial[0];
      h += `<div class="a tab" style="${st}">` + v.parameter_enum.map((t, i) => `<div class="${i === d ? "on" : ""}" style="font-size:${fs_}">${t}</div>`).join("") + "</div>";
    } else if (b.maxclass === "live.dial") {
      const lo = v.parameter_mmin, hi = v.parameter_mmax, val = (set && set[b.varname] !== undefined) ? set[b.varname] : v.parameter_initial[0];
      const f = (val - lo) / (hi - lo), r = Math.min(w, hh - 24) / 2 - 3, cx = w / 2, cy = 16 + r;
      const a0 = Math.PI * 0.75, a1 = a0 + f * Math.PI * 1.5, A = a => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
      const [x0, y0] = A(a0), [x1, y1] = A(a1), [x2, y2] = A(Math.PI * 2.25);
      const unit = v.parameter_unitstyle === 5 ? " %" : "";
      h += `<div class="a" style="${st}"><div class="lbl" style="font-size:11px">${v.parameter_shortname}</div>
<svg style="position:absolute;left:0;top:0" width="${w}" height="${hh}"><path d="M${x0} ${y0} A${r} ${r} 0 1 1 ${x2} ${y2}" fill="none" stroke="#2a2a2a" stroke-width="3"/>
<path d="M${x0} ${y0} A${r} ${r} 0 ${f > 0.66 ? 1 : 0} 1 ${x1} ${y1}" fill="none" stroke="#f0a020" stroke-width="3"/><line x1="${cx}" y1="${cy}" x2="${x1}" y2="${y1}" stroke="#ddd" stroke-width="2"/></svg>
<div class="lbl" style="position:absolute;bottom:0;width:100%;font-size:11px;color:#ddd">${Math.round(val)}${unit}</div></div>`;
    }
  }
  return { html: h, width: p.devicewidth };
}

(async () => {
  const b = await chromium.launch();
  for (const d of DEV) {
    const c = controls(d.name, d.set);
    const html = `<!doctype html><html><head><meta charset="utf-8"><style>
body{margin:0;background:#3a3a3a;font-family:Arial,Helvetica,sans-serif}
.dev{position:relative;width:${c.width}px;height:169px;background:#3e3e3e}
.a{position:absolute;box-sizing:border-box}
.lbl{color:#cfcfcf;text-align:center;font-weight:bold}
.tab{display:flex;gap:1px}.tab div{flex:1;background:#595959;color:#ddd;font-weight:bold;display:flex;align-items:center;justify-content:center}
.tab div.on{background:#f0a020;color:#1e1e1e}
.btn{background:#595959;color:#ddd;font-weight:bold;display:flex;align-items:center;justify-content:center}
.btn.on{background:#f0a020;color:#1e1e1e}
</style></head><body><div class="dev">
<canvas id="c" class="a" style="left:4px;top:4px;width:300px;height:161px" width="600" height="322"></canvas>
${c.html}</div><script>
const cv = document.getElementById("c"), cx = cv.getContext("2d"); cx.scale(2, 2);
let fsz = 10, path = 0;
var mgraphics = { size: [300, 161], init(){}, redraw(){},
  set_source_rgba(r,g,b,a){ const s = "rgba(" + [r*255|0, g*255|0, b*255|0, a].join(",") + ")"; cx.fillStyle = s; cx.strokeStyle = s; },
  rectangle(x,y,w,h){ if (!path) { cx.beginPath(); path = 1; } cx.rect(x,y,w,h); },
  fill(){ cx.fill(); path = 0; }, stroke(){ cx.stroke(); path = 0; },
  set_line_width(w){ cx.lineWidth = w; }, move_to(x,y){ if (!path) { cx.beginPath(); path = 1; } cx.moveTo(x,y); this.tx = x; this.ty = y; },
  line_to(x,y){ cx.lineTo(x,y); }, select_font_face(){}, set_font_size(s){ fsz = s; cx.font = "bold " + s + "px Arial"; },
  text_measure(s){ return [cx.measureText(s).width, fsz]; }, show_text(s){ cx.fillText(s, this.tx, this.ty); path = 0; } };
function outlet(){} function arrayfromargs(a){ return Array.prototype.slice.call(a); }
var inlets, outlets;
var KIND = "${d.kind}";
${CORE}
// a drum bar: kick, snare, hats, an open hat, a rim
var BAR = [[36,110,0],[36,110,4],[36,90,7],[36,110,8],[36,110,12],[38,100,4],[38,100,12],[37,60,11],
  [42,80,2],[42,60,3],[42,80,6],[42,80,10],[42,55,13],[46,90,14]];
${d.setup}
learnlen(0); learn();
var g;
for (g = 0; g < 16 * (2 + ${d.bars}) + 5; g++) {
  for (var i = 0; i < BAR.length; i++) { var at = Math.floor(g/16)*16 + BAR[i][2]; if (at == g && mode != "play") { note(BAR[i][0], BAR[i][1], at); note(BAR[i][0], 0, at + 0.5); } }
  tick(g);
}
paint();
</script></body></html>`;
    const p = await b.newPage({ viewport: { width: c.width, height: 169 }, deviceScaleFactor: 2 });
    p.on("pageerror", e => console.log(d.name, "ERROR", e.message));
    await p.setContent(html);
    await p.screenshot({ path: path.join(ROOT, "previews", d.name + ".png") });
    await p.close();
    console.log("wrote previews/" + d.name + ".png");
  }
  await b.close();
})();
