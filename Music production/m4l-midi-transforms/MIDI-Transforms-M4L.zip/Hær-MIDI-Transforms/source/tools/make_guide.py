#!/usr/bin/env python3
"""Puts the current script names into README.md and turns it into a PDF.
    python3 tools/make_guide.py out.pdf"""
import base64, glob, os, re, subprocess, sys, markdown
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
md = open(os.path.join(ROOT, "README.md")).read()
for kind in ("mutator", "euclid", "markov"):
    js = os.path.basename(glob.glob(os.path.join(ROOT, "dist", kind + "_*.js"))[0])
    md = re.sub(r"`%s_[0-9a-f]{8}\.js`" % kind, "`%s`" % js, md)
open(os.path.join(ROOT, "README.md"), "w").write(md)
for n in ("Mutator", "EuclidMorph", "MarkovRemix"):
    img = base64.b64encode(open(os.path.join(ROOT, "previews", n + ".png"), "rb").read()).decode()
    md = md.replace("(previews/%s.png)" % n, "(data:image/png;base64,%s)" % img)
body = markdown.markdown(md, extensions=["tables", "fenced_code"])
html = """<!doctype html><html><head><meta charset="utf-8"><style>
body{font-family:Helvetica,Arial,sans-serif;font-size:11.5pt;line-height:1.45;color:#222;margin:0}
h1{color:#c07810;font-size:24pt;margin:0 0 8pt} h2{color:#c07810;font-size:16pt;margin:20pt 0 6pt;border-bottom:1px solid #eee;page-break-after:avoid}
img{width:100%%;border-radius:4px} blockquote{background:#fff4e0;border-left:4px solid #f0a020;margin:10pt 0;padding:4pt 10pt}
code{font-family:Menlo,monospace;font-size:9.5pt;background:#f4f1ea;padding:0 2px}
table{border-collapse:collapse;width:100%%;font-size:10.5pt;page-break-inside:avoid} td,th{border:1px solid #ddd;padding:4pt 6pt;vertical-align:top;text-align:left}
th{background:#f7f2e8} td:first-child{white-space:nowrap;font-weight:bold}
</style></head><body>%s</body></html>""" % body
tmp = os.path.join(ROOT, "_guide.html")
open(tmp, "w").write(html)
js = """const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.goto('file://'+process.argv[1]);await p.pdf({path:process.argv[2],format:'A4',margin:{top:'16mm',bottom:'16mm',left:'16mm',right:'16mm'}});await b.close()})()"""
subprocess.check_call(["node", "-e", js, tmp, os.path.abspath(sys.argv[1])])
os.remove(tmp)
