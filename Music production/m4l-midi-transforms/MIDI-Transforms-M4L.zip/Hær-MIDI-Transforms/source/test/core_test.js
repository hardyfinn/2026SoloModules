// Runs transform_core.js outside Max with a fake Max environment and checks the logic.
//   node test/core_test.js
"use strict";
const fs = require("fs"), path = require("path"), vm = require("vm");
const CODE = fs.readFileSync(path.join(__dirname, "..", "src", "transform_core.js"), "utf8");

function load(kind, seed) {
  const out = [];
  let s = seed || 1;
  const rand = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  const math = Object.create(Math); math.random = rand;
  const ctx = {
    KIND: kind, Math: math, out,
    outlet: (n, ...a) => out.push([].concat(...a)),
    arrayfromargs: (args) => Array.prototype.slice.call(args),
    mgraphics: { init() {}, redraw() {}, size: [300, 160] },
    post() {},
  };
  vm.createContext(ctx);
  vm.runInContext(CODE, ctx);
  return ctx;
}

// the [coll] as the patch would hold it after the messages so far
function collOf(out) {
  const c = {};
  for (const m of out) {
    if (m[0] !== "coll") continue;
    if (m[1] === "clear") for (const k in c) delete c[k];
    if (m[1] === "store") c[m[2]] = m.slice(3);
  }
  return c;
}
function eventsOfColl(c) {
  const e = [];
  for (const k in c) for (let i = 0; i < c[k].length; i += 4) e.push({ step: +k, p: c[k][i], v: c[k][i + 1], d: c[k][i + 2], o: c[k][i + 3] });
  return e.sort((a, b) => a.step - b.step || a.p - b.p);
}

// a drum bar: kick 36 on 0,4,8,12; snare 38 on 4,12; hat 42 on every odd 8th; one early hat
const BAR = [];
for (const s of [0, 4, 8, 12]) BAR.push([36, 110, s]);
for (const s of [4, 12]) BAR.push([38, 100, s]);
for (const s of [2, 6, 10]) BAR.push([42, 80, s]);
BAR.push([42, 70, 14 - 0.1]);     // played a little early

// play the device from song step `from` to `to`, feeding `bar` repeatedly (as a clip would)
function run(dev, from, to, bar) {
  for (let g = from; g < to; g++) {
    if (bar) for (const [p, v, s] of bar) {
      const at = Math.floor(g / 16) * 16 + s;
      if (at >= g - 0.5 && at < g + 0.5) { dev.note(p, v, at); dev.note(p, 0, at + 0.5); }
    }
    dev.tick(g);
  }
}

let fails = 0, n = 0;
function check(name, cond) { n++; if (!cond) { fails++; console.log("FAIL", name); } else console.log("ok  ", name); }

// ---- learning --------------------------------------------------------------------------------
{
  const d = load("mutator");
  d.learnlen(0); d.everyset(4); d.hold(1);
  run(d, 0, 20, BAR);            // plays bar 1 in THRU
  d.learn();                      // pressed in bar 2: learning starts at step 32
  run(d, 20, 64, BAR);
  check("armed waits for the bar line, then learns one bar", d.mode === "play" && d.s0 === 32 && d.L === 16);
  check("learned every note of the bar", d.orig.length === BAR.length);
  const early = d.orig.find(e => e.p === 42 && Math.abs(e.pos - 13.9) < 1e-6);
  check("an early note keeps its feel (pos 13.9)", !!early);
  const c = eventsOfColl(collOf(d.out));
  check("coll holds all notes", c.length === BAR.length);
  const e2 = c.find(e => e.p === 42 && e.step === 13);
  check("early hat stored at step 13 with offset 0.9", e2 && Math.abs(e2.o - 0.9) < 1e-6);
  const sw = d.out.filter(m => m[0] === "sw").map(m => m[1]);
  check("takes over at step 48, then plays from anywhere", sw.includes(48) && sw[sw.length - 1] === -1e9);
  check("pattern saved to the set", d.out.some(m => m[0] === "save"));
  // restore into a fresh device
  const save = d.out.filter(m => m[0] === "save").pop().slice(1);
  const d2 = load("mutator");
  d2.restore(...save);
  check("restore gives the same pattern", JSON.stringify(d2.orig) === JSON.stringify(d.orig) && d2.mode === "play");
  // learning 2 bars starting mid-song: keys follow the song position
  const d3 = load("euclid");
  d3.learnlen(1); d3.learn();
  run(d3, 5, 16 * 5, BAR);
  check("2-bar learn starts on bar line 16", d3.s0 === 16 && d3.L === 32 && d3.orig.length === 2 * BAR.length);
}

// ---- Mutator ---------------------------------------------------------------------------------
{
  const d = load("mutator", 7);
  d.learnlen(0); d.everyset(0); d.hold(0);
  d.learn(); run(d, 0, 32, BAR);
  const before = JSON.stringify(d.cur);
  check("first pass plays the original (learned bar 1, no change before bar 3)", d.playFrom === 16);
  const c0 = d.changes;
  run(d, 32, 32 + 16 * 8, null);
  check("one change per bar (8 bars -> 8 changes)", d.changes === c0 + 8);
  check("pattern changed", JSON.stringify(d.cur) !== before);
  // each change is small: the pattern differs from the previous by at most one lane
  let maxDiff = 0;
  {
    const e = load("mutator", 3); e.learnlen(0); e.everyset(0); e.learn(); run(e, 0, 32, BAR);
    for (let b = 0; b < 30; b++) {
      const prev = e.cur.map(x => x.p + "@" + x.pos).sort();
      run(e, 32 + b * 16, 48 + b * 16, null);
      const now = e.cur.map(x => x.p + "@" + x.pos).sort();
      const gone = prev.filter(x => !now.includes(x)).length, born = now.filter(x => !prev.includes(x)).length;
      const lanes = new Set(prev.filter(x => !now.includes(x)).concat(now.filter(x => !prev.includes(x))).map(x => x.split("@")[0]));
      maxDiff = Math.max(maxDiff, lanes.size);
    }
    check("each change touches only one lane", maxDiff <= 1);
    check("never empties the pattern", e.cur.length >= 1);
  }
  d.revert();
  check("REVERT restores what you played", JSON.stringify(d.cur) === JSON.stringify(d.orig));
  const c = eventsOfColl(collOf(d.out));
  check("REVERT rewrites the coll", c.length === BAR.length);
  d.hold(1); const ch = d.changes;
  run(d, 32 + 16 * 8, 32 + 16 * 12, null);
  check("HOLD stops changes", d.changes === ch);
  d.hold(0); d.everyset(2);   // every 4 bars
  run(d, 160, 160 + 64, null);
  check("EVERY 4 bars -> 4 bars gives one change", d.changes === ch + 1);
  d.rotate(0); d.drop(0); d.shift(0); d.add(0);
  d.now();
  check("all change types off -> NOW does nothing", d.changes === ch + 1);
  d.shift(1); d.now();
  check("NOW makes one change straight away", d.changes === ch + 2);
  d.keep();
  check("KEEP makes the current pattern the original", JSON.stringify(d.cur) === JSON.stringify(d.orig));
}

// ---- Euclid Morph -----------------------------------------------------------------------------
{
  // a lopsided lane: 4 hits bunched at 0,1,2,3 over 16 steps
  const LOP = [[36, 100, 0], [36, 100, 1], [36, 100, 2], [36, 100, 3], [42, 90, 0], [42, 90, 5], [42, 90, 6]];
  const d = load("euclid");
  d.learnlen(0); d.morph(0); d.learn(); run(d, 0, 32, LOP);
  const p = x => d.cur.filter(e => e.p === x).map(e => +e.pos.toFixed(3)).sort((a, b) => a - b);
  check("MORPH 0% = the original", JSON.stringify(p(36)) === "[0,1,2,3]");
  d.morph(100);
  const k = p(36);
  const gaps = k.map((x, i) => (k[(i + 1) % k.length] - x + 16) % 16);
  check("MORPH 100%: 4 kicks spread evenly (gaps of 4) " + JSON.stringify(k), gaps.every(g => g === 4));
  const h = p(42);
  const hg = h.map((x, i) => (h[(i + 1) % h.length] - x + 16) % 16);
  check("MORPH 100%: 3 hats spread 5/5/6 " + JSON.stringify(h), hg.slice().sort().join() === "5,5,6");
  check("hit count kept", d.cur.length === LOP.length);
  d.morph(50);
  const m = p(36);
  check("MORPH 50%: hits halfway (between the two)", m.some(x => x % 1 !== 0) || JSON.stringify(m) !== JSON.stringify(k));
  d.morph(100); d.hits(2);
  check("HITS +2 adds two kicks at 100%", p(36).length === 6);
  d.morph(30);
  check("HITS +2: new hits only appear past 50%", p(36).length === 4);
  d.hits(-2); d.morph(100);
  check("HITS -2 leaves two kicks at 100%", p(36).length === 2);
  d.hits(0); d.turn(1);
  const t = p(36);
  check("TURN moves the even pattern one step", JSON.stringify(t) !== JSON.stringify(k) && t.length === 4);
  d.turn(0); d.lanes(1);
  check("TOGETHER: all notes as one lane keep their count", d.cur.length === LOP.length);
  const coll = eventsOfColl(collOf(d.out));
  check("morph writes the coll", coll.length === LOP.length);
}

// ---- Markov Remix -----------------------------------------------------------------------------
{
  const d = load("markov", 11);
  d.learnlen(1); d.strictness(100); d.newevery(0);
  d.learn(); run(d, 0, 48, BAR);
  check("learned 2 bars", d.L === 32 && d.orig.length === 2 * BAR.length);
  run(d, 48, 48 + 64, null);
  const key = a => a.map(e => e.p + "@" + e.pos.toFixed(3)).sort().join();
  check("STRICTNESS 100% remakes the original exactly", key(d.cur) === key(d.orig) && d.gens >= 3);
  d.strictness(0);
  let differs = 0, similar = 0;
  for (let i = 0; i < 20; i++) {
    run(d, 112 + i * 16, 128 + i * 16, null);
    if (key(d.cur) !== key(d.orig)) differs++;
    // "same feel": every step's content exists somewhere in the original
    const sigs = new Set();
    const sig = (arr, s) => arr.filter(e => Math.floor(e.pos + 0.5) % 32 === s).map(e => e.p).sort().join(".");
    for (let s = 0; s < 32; s++) sigs.add(sig(d.orig, s));
    let ok = true; for (let s = 0; s < 32; s++) if (!sigs.has(sig(d.cur, s))) ok = false;
    if (ok) similar++;
  }
  check("STRICTNESS 0% makes new bars (" + differs + "/20 differ)", differs >= 15);
  check("...built only from steps that were in the original", similar === 20);
  d.kitmode(1);
  run(d, 600, 616, null);
  check("LANES mode makes notes of the learned pitches", d.cur.every(e => [36, 38, 42].includes(e.p)) && d.cur.length > 0);
  d.original(1);
  const c = eventsOfColl(collOf(d.out));
  check("ORIGINAL plays what you played", c.length === d.orig.length);
  const g0 = d.gens;
  run(d, 616, 680, null);
  check("ORIGINAL holds: no new remixes", d.gens === g0);
  d.original(0); d.newevery(4); d.newbar();
  run(d, 680, 696, null);
  check("NEW makes a remix at the next bar even on 'never'", d.gens === g0 + 1);
}

// ---- THRU ---------------------------------------------------------------------------------------
{
  const d = load("mutator");
  d.learn(); run(d, 0, 32, BAR);
  d.thru();
  check("THRU stops the device (sw = never)", d.mode === "thru" && d.S === 1e9);
  d.thru();
  check("THRU again plays the pattern again", d.mode === "play" && d.S === -1e9);
  const panic = d.out.filter(m => m[0] === "panic").length;
  d.running(0);
  check("transport stop -> panic", d.out.filter(m => m[0] === "panic").length === panic + 1);
  const f = load("euclid"); f.learn(); run(f, 0, 8, BAR); f.running(0);
  check("stop while learning -> armed again", f.mode === "armed" && f.S === 1e9);
  run(f, 0, 32, BAR);
  check("...and learns cleanly after restarting from the top", f.mode === "play" && f.orig.length === BAR.length);
  const e = load("markov"); e.learn(); run(e, 0, 40, null);
  check("learning silence goes back to THRU", e.mode === "thru" && e.orig.length === 0);
}


// ---- the patch's player, simulated: does what comes out match what went in? ----------------------
{
  // learn starting mid-song (bar 3) so the coll keys must follow the song position
  const d = load("mutator");
  d.learnlen(1); d.hold(1);
  run(d, 0, 40, BAR);
  d.learn();
  // the patch: sw and len as the brain last set them, coll contents, then g -> if -> % -> coll
  let S = 1e9, L = 16; const coll = {}; let seen = 0;
  const played = [];
  function patchStep(g) {
    for (; seen < d.out.length; seen++) {
      const m = d.out[seen];
      if (m[0] === "sw") S = m[1];
      if (m[0] === "len") L = m[1];
      if (m[0] === "coll" && m[1] === "clear") for (const k in coll) delete coll[k];
      if (m[0] === "coll" && m[1] === "store") coll[m[2]] = m.slice(3);
    }
    if (g >= S) { const ev = coll[g % L] || []; for (let i = 0; i < ev.length; i += 4) played.push([ev[i], +(g + ev[i + 3]).toFixed(3)]); }
  }
  for (let g = 40; g < 200; g++) {
    patchStep(g);                       // high priority: plays first...
    for (const [p, v, s] of BAR) { const at = Math.floor(g / 16) * 16 + s; if (at >= g - 0.5 && at < g + 0.5) { d.note(p, v, at); d.note(p, 0, at + 0.5); } }
    d.tick(g);                          // ...then the brain hears the tick
  }
  // learning was bars at 48..79 (2 bars), the device plays from 80
  const want = [];
  for (let b = 80; b < 200; b += 16) for (const [p, , s] of BAR) if (b + s >= 80 - 0.5 && b + s < 200 - 0.5) want.push([p, +(b + s).toFixed(3)]);
  const key = a => a.map(x => x.join("@")).sort().join();
  const firstTake = played.length ? Math.min(...played.map(x => x[1])) : -1;
  check("device takes over at bar line 80 (" + firstTake + ")", firstTake >= 79.5 && firstTake < 80.5);
  check("played back exactly the learned 2 bars, early hat included", key(played) === key(want.filter(w => w[1] >= 79.5)));
}

console.log(`\n${n - fails}/${n} checks passed`);
process.exit(fails ? 1 : 0);
