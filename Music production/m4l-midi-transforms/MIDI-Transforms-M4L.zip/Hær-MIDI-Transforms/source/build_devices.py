#!/usr/bin/env python3
"""Builds the three Hær MIDI transform devices (Max for Live MIDI effects):

    python3 build_devices.py        writes dist/Mutator.amxd, dist/EuclidMorph.amxd, dist/MarkovRemix.amxd
                                    (+ a .maxpat copy of each, and the .js each one needs beside it)

Every device is the same patch around a different brain:

  TIMING (high priority, no script involved)
    metro 16n @quantize 16n -> transport -> expr: song step g (16ths since the start)
    g -> [if g >= takeover step] -> [% loop length] -> [coll] -> each note:
         offset and duration (in 16ths) x ms-per-16th -> [pipe] -> [makenote] -> midiformat -> midiout
  INPUT
    midiin -> midiparse -> note + its song position (transport again, at that moment)
         -> to the brain, and through a [gate] while the device is not playing (note-offs always pass)
    CC, pitch bend, aftertouch, program change pass straight through
  BRAIN (src/transform_core.js in a jsui, which is also the display)
    learns, changes the pattern, writes the [coll] a 16th before it is needed,
    saves the learned pattern in a [pattr] that is kept with the Live set
"""
import hashlib, json, os, struct

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "dist")
CORE = open(os.path.join(HERE, "src", "transform_core.js")).read()

NONE = 1000000000


class Patch:
    def __init__(self):
        self.boxes, self.lines, self.n = [], [], 0

    def add(self, box):
        self.n += 1
        box["id"] = "obj-%d" % self.n
        self.boxes.append({"box": box})
        return box["id"]

    def obj(self, text, x, y, ins=1, outs=1, types=None, w=None, **extra):
        b = {"maxclass": "newobj", "text": text, "numinlets": ins, "numoutlets": outs,
             "outlettype": types if types is not None else [""] * outs,
             "patching_rect": [x, y, w or max(30, 7 * len(text) + 12), 22.0]}
        b.update(extra)
        return self.add(b)

    def msg(self, text, x, y):
        return self.add({"maxclass": "message", "text": text, "numinlets": 2, "numoutlets": 1,
                         "outlettype": [""], "patching_rect": [x, y, max(30, 7 * len(text) + 14), 22.0]})

    def comment(self, text, x, y, w=300, pres=None, size=None, color=None, center=False):
        b = {"maxclass": "comment", "text": text, "numinlets": 1, "numoutlets": 0,
             "patching_rect": [x, y, w, 20.0]}
        if pres:
            b.update({"presentation": 1, "presentation_rect": pres,
                      "textcolor": color or [0.8, 0.8, 0.8, 1.0]})
        if size:
            b["fontsize"] = size
        if center:
            b["textjustification"] = 1
        return self.add(b)

    def connect(self, a, ao, b, bi=0):
        self.lines.append({"patchline": {"source": [a, ao], "destination": [b, bi]}})


def valueof(longname, short, ptype, extra):
    v = {"parameter_longname": longname, "parameter_shortname": short, "parameter_type": ptype}
    v.update(extra)
    return {"valueof": v}


def patcher_dict(boxes, lines, rect, extra=None):
    d = {"fileversion": 1,
         "appversion": {"major": 9, "minor": 0, "revision": 0, "architecture": "x64", "modernui": 1},
         "classnamespace": "box", "rect": rect, "bglocked": 0, "openinpresentation": 1,
         "default_fontsize": 10.0, "default_fontface": 0, "default_fontname": "Arial Bold",
         "gridonopen": 1, "gridsize": [15.0, 15.0], "gridsnaponopen": 1, "objectsnaponopen": 1,
         "statusbarvisible": 2, "toolbarvisible": 1, "lefttoolbarpinned": 0, "toptoolbarpinned": 0,
         "righttoolbarpinned": 0, "bottomtoolbarpinned": 0, "toolbars_unpinned_last_save": 0,
         "tallnewobj": 0, "boxanimatetime": 200, "enablehscroll": 1, "enablevscroll": 1,
         "devicewidth": 0.0, "description": "", "digest": "", "tags": "", "style": "",
         "subpatcher_template": "", "assistshowspatchername": 0,
         "boxes": boxes, "lines": lines}
    if extra:
        d.update(extra)
    return d


# ---- Live controls -------------------------------------------------------------------------------
def dial(P, long, short, lo, hi, dflt, unitstyle, pres, units=None, steps=None):
    extra = {"parameter_mmin": lo, "parameter_mmax": hi, "parameter_initial_enable": 1,
             "parameter_initial": [dflt], "parameter_unitstyle": unitstyle}
    if units:
        extra["parameter_units"] = units
    if steps:
        extra["parameter_steps"] = steps
    return P.add({"maxclass": "live.dial", "varname": long, "numinlets": 1, "numoutlets": 2,
                  "outlettype": ["", "float"], "patching_rect": [pres[0] + 700, pres[1] + 600, 44, 48],
                  "presentation": 1, "presentation_rect": pres, "parameter_enable": 1,
                  "fontsize": 11.0, "showname": 1, "shownumber": 1,
                  "saved_attribute_attributes": valueof(long, short, 1 if unitstyle == 0 else 0, extra)})


def toggle(P, long, short, text, pres, dflt=0, fontsize=12.0):
    extra = {"parameter_enum": ["off", "on"], "parameter_mmax": 1, "parameter_initial_enable": 1,
             "parameter_initial": [dflt]}
    return P.add({"maxclass": "live.text", "varname": long, "text": text, "texton": text, "mode": 1,
                  "numinlets": 1, "numoutlets": 2, "outlettype": ["", ""],
                  "patching_rect": [pres[0] + 700, pres[1] + 600, 60, 18], "fontsize": fontsize,
                  "presentation": 1, "presentation_rect": pres, "parameter_enable": 1,
                  "saved_attribute_attributes": valueof(long, short, 2, extra)})


def button(P, long, short, text, pres, fontsize=13.0):
    return P.add({"maxclass": "live.text", "varname": long, "text": text, "texton": text, "mode": 0,
                  "numinlets": 1, "numoutlets": 2, "outlettype": ["", ""],
                  "patching_rect": [pres[0] + 700, pres[1] + 600, 60, 18], "fontsize": fontsize,
                  "presentation": 1, "presentation_rect": pres, "parameter_enable": 1,
                  "saved_attribute_attributes": valueof(long, short, 2, {"parameter_enum": ["off", "on"],
                                                                         "parameter_mmax": 1})})


def tab(P, long, short, items, dflt, pres, fontsize=12.0):
    extra = {"parameter_enum": items, "parameter_mmax": len(items) - 1,
             "parameter_initial_enable": 1, "parameter_initial": [dflt]}
    return P.add({"maxclass": "live.tab", "varname": long, "numinlets": 1, "numoutlets": 3,
                  "outlettype": ["", "", "float"], "patching_rect": [pres[0] + 700, pres[1] + 600, 100, 20],
                  "presentation": 1, "presentation_rect": pres, "parameter_enable": 1,
                  "num_lines_patching": 1, "num_lines_presentation": 1, "fontsize": fontsize,
                  "saved_attribute_attributes": valueof(long, short, 2, extra)})


def label(P, text, pres, size=12.0):
    return P.comment(text, 0, 0, 10, pres=pres, size=size, center=True)


class Device:
    """The shared patch. Controls are wired with value() and press()."""

    def __init__(self, kind, title):
        self.kind, self.title = kind, title
        code = 'var KIND = "%s";\n' % kind + CORE
        self.js_name = kind + "_" + hashlib.blake2b(code.encode(), digest_size=4).hexdigest() + ".js"
        self.js_code = code
        self.values = []            # controls that send their value again when the device loads
        P = self.P = Patch()
        P.comment(title + ": the timing chain plays the pattern, the jsui (" + self.js_name +
                  ") is the brain and the display.", 20, 5, 800)

        # ---- the brain / display ----
        self.js = P.add({"maxclass": "jsui", "filename": self.js_name, "numinlets": 1, "numoutlets": 1,
                         "outlettype": [""], "parameter_enable": 0, "border": 0,
                         "patching_rect": [700, 330, 300, 161], "presentation": 1,
                         "presentation_rect": [4, 4, 300, 161]})
        rt = P.obj("route sw len coll panic save", 700, 510, 1, 6)
        P.connect(self.js, 0, rt, 0)

        # ---- timing: the song step every 16th ----
        met = P.obj("metro 16n @quantize 16n @active 1", 20, 40, 2, 1, ["bang"])
        trA = P.obj("transport", 20, 75, 2, 9, ["int", "int", "float", "float", "float", "", "int", "float", ""])
        P.connect(met, 0, trA, 0)
        stp = P.obj("expr int(($f1-1.)*16.+($f2-1.)*4.+$f3/120.+0.5)", 20, 110, 3, 1, ["int"])
        for i in range(3):
            P.connect(trA, i, stp, i)
        tt = P.obj("t i i", 20, 145, 1, 2, ["int", "int"])
        P.connect(stp, 0, tt, 0)
        ptk = P.obj("prepend tick", 160, 180)
        P.connect(tt, 1, ptk, 0)
        P.connect(ptk, 0, self.js, 0)
        gate_g = P.obj("if $i1 >= $i2 then $i1", 20, 180, 2, 1)
        P.connect(tt, 0, gate_g, 0)
        mod = P.obj("% 16", 20, 215, 2, 1, ["int"])
        P.connect(gate_g, 0, mod, 0)
        coll = P.obj("coll ---mtpat", 20, 250, 1, 4, ["", "", "", "bang"])
        P.connect(mod, 0, coll, 0)
        it = P.obj("zl iter 4", 20, 285, 2, 2, ["", ""])
        P.connect(coll, 0, it, 0)
        up = P.obj("unpack 0 0 0. 0.", 20, 320, 1, 4, ["int", "int", "float", "float"])
        P.connect(it, 0, up, 0)
        moff = P.obj("expr $f1*$f2", 250, 355, 2, 1)
        mdur = P.obj("expr $f1*$f2", 170, 355, 2, 1)
        P.connect(up, 3, moff, 0)
        P.connect(up, 2, mdur, 0)
        pipe = P.obj("pipe 0 0 0. 0", 20, 390, 4, 3, ["", "", ""])
        P.connect(up, 0, pipe, 0)
        P.connect(up, 1, pipe, 1)
        P.connect(mdur, 0, pipe, 2)
        P.connect(moff, 0, pipe, 3)
        mk = P.obj("makenote 100 100", 20, 425, 3, 2, ["float", "float"])
        for i in range(3):
            P.connect(pipe, i, mk, i)
        pk2 = P.obj("pack 0 0", 20, 460, 2, 1)
        P.connect(mk, 0, pk2, 0)
        P.connect(mk, 1, pk2, 1)
        fmt = P.obj("midiformat", 20, 560, 7, 1, ["int"])
        P.connect(pk2, 0, fmt, 0)
        mout = P.obj("midiout", 20, 595, 1, 0)
        P.connect(fmt, 0, mout, 0)

        # takeover step and loop length come from the brain
        P.connect(rt, 0, gate_g, 1)
        P.connect(rt, 1, mod, 1)
        P.connect(rt, 2, coll, 0)

        # ---- tempo (ms per 16th) and transport running ----
        qm = P.obj("qmetro 50 @active 1", 330, 40, 2, 1, ["bang"])
        trC = P.obj("transport", 330, 75, 2, 9, ["int", "int", "float", "float", "float", "", "int", "float", ""])
        P.connect(qm, 0, trC, 0)
        tch = P.obj("change 0.", 330, 110, 1, 3, ["", "int", "int"])
        P.connect(trC, 4, tch, 0)
        msp = P.obj("expr 15000./$f1", 330, 145, 1, 1)
        P.connect(tch, 0, msp, 0)
        P.connect(msp, 0, moff, 1)
        P.connect(msp, 0, mdur, 1)
        rch = P.obj("change", 470, 110, 1, 3, ["", "int", "int"])
        P.connect(trC, 6, rch, 0)
        prun = P.obj("prepend running", 470, 145)
        P.connect(rch, 0, prun, 0)
        P.connect(prun, 0, self.js, 0)
        sel0 = P.obj("sel 0", 600, 145, 2, 2, ["bang", ""])
        P.connect(rch, 0, sel0, 0)

        # ---- panic: drop pending notes, send note-offs ----
        tp = P.obj("t b b", 600, 210, 1, 2, ["bang", "bang"])
        P.connect(sel0, 0, tp, 0)
        P.connect(rt, 3, tp, 0)
        mclr = P.msg("clear", 600, 245)
        mstop = P.msg("stop", 660, 245)
        P.connect(tp, 1, mclr, 0)
        P.connect(tp, 0, mstop, 0)
        P.connect(mclr, 0, pipe, 0)
        P.connect(mstop, 0, mk, 0)

        # ---- input ----
        mi = P.obj("midiin", 330, 300, 1, 1, ["int"])
        mp = P.obj("midiparse", 330, 335, 1, 8, ["", "", "", "int", "int", "int", "int", ""])
        P.connect(mi, 0, mp, 0)
        for o in (1, 2, 3, 4, 5, 6):            # everything that isn't a note passes straight through
            P.connect(mp, o, fmt, o)
        tlb = P.obj("t l b", 330, 370, 1, 2, ["", "bang"])
        P.connect(mp, 0, tlb, 0)
        trB = P.obj("transport", 450, 405, 2, 9, ["int", "int", "float", "float", "float", "", "int", "float", ""])
        P.connect(tlb, 1, trB, 0)
        pos = P.obj("expr ($f1-1.)*16.+($f2-1.)*4.+$f3/120.", 450, 440, 3, 1)
        for i in range(3):
            P.connect(trB, i, pos, i)
        pk3 = P.obj("pack 0 0 0.", 330, 475, 3, 1)
        P.connect(pos, 0, pk3, 2)
        P.connect(tlb, 0, pk3, 0)
        t3 = P.obj("t l l l", 330, 510, 1, 3, ["", "", ""])
        P.connect(pk3, 0, t3, 0)
        pnote = P.obj("prepend note", 520, 545)
        P.connect(t3, 2, pnote, 0)
        P.connect(pnote, 0, self.js, 0)
        # a note passes through while the device isn't playing; note-offs always pass
        thr = P.obj("expr ($i2==0)||($f3<($f4-0.5))", 420, 545, 4, 1)
        P.connect(t3, 1, thr, 0)
        P.connect(rt, 0, thr, 3)
        sl = P.obj("zl slice 2", 330, 580, 2, 2, ["", ""])
        P.connect(t3, 0, sl, 0)
        gt = P.obj("gate 1 0", 330, 615, 2, 1)
        P.connect(thr, 0, gt, 0)
        P.connect(sl, 0, gt, 1)
        P.connect(gt, 0, fmt, 0)

        # ---- the learned pattern is kept with the Live set ----
        psv = P.obj("prepend set", 870, 545)
        P.connect(rt, 4, psv, 0)
        self.pattr = P.add({"maxclass": "newobj", "text": "pattr learned", "numinlets": 1, "numoutlets": 3,
                            "outlettype": ["", "", ""], "patching_rect": [870, 580, 90, 22],
                            "parameter_enable": 1,
                            "saved_attribute_attributes": valueof("Learned pattern", "Learned", 3,
                                                                  {"parameter_invisible": 1})})
        P.connect(psv, 0, self.pattr, 0)
        prs = P.obj("prepend restore", 870, 615)
        P.connect(self.pattr, 0, prs, 0)
        P.connect(prs, 0, self.js, 0)

        # ---- when loading: "never take over" first (high priority), then the brain ----
        lb = P.obj("loadbang", 1000, 40, 1, 1, ["bang"])
        mnone = P.msg(str(NONE), 1000, 75)
        P.connect(lb, 0, mnone, 0)
        P.connect(mnone, 0, gate_g, 1)
        P.connect(mnone, 0, thr, 3)
        dev = P.obj("live.thisdevice", 1000, 110, 1, 3, ["bang", "int", "int"])
        self.tload = P.obj("t b b b", 1000, 145, 1, 3, ["bang", "bang", "bang"])
        P.connect(dev, 0, self.tload, 0)
        minit = P.msg("init", 1000, 180)
        P.connect(self.tload, 2, minit, 0)
        P.connect(minit, 0, self.js, 0)
        P.connect(self.tload, 1, self.pattr, 0)

        # ---- shared controls: LEARN, length, THRU ----
        lrn = button(P, "Learn", "Learn", "LEARN", [310, 4, 100, 30], fontsize=15.0)
        self.press(lrn, "learn")
        label(P, "Length (bars)", [310, 38, 100, 18])
        ln = tab(P, "Length", "Length", ["1", "2", "4", "8"], 0, [310, 56, 100, 22])
        self.value(ln, "learnlen")
        th = button(P, "Thru", "Thru", "THRU", [310, 84, 100, 26], fontsize=13.0)
        self.press(th, "thru")

    def value(self, ctl, name):
        P = self.P
        b = [bx["box"] for bx in P.boxes if bx["box"]["id"] == ctl][0]
        x, y = b["patching_rect"][0], b["patching_rect"][1] + 30
        pr = P.obj("prepend " + name, x, y)
        P.connect(ctl, 0, pr, 0)
        P.connect(pr, 0, self.js, 0)
        self.values.append(ctl)

    def press(self, ctl, name):
        P = self.P
        b = [bx["box"] for bx in P.boxes if bx["box"]["id"] == ctl][0]
        x, y = b["patching_rect"][0], b["patching_rect"][1] + 30
        rt = P.obj("route bang 1", x, y, 1, 3)
        P.connect(ctl, 0, rt, 0)
        m = P.msg(name, x, y + 30)
        P.connect(rt, 0, m, 0)
        P.connect(rt, 1, m, 0)
        P.connect(m, 0, self.js, 0)

    def finish(self, width):
        P = self.P
        for c in self.values:                        # on load every control sends its value again
            P.connect(self.tload, 0, c, 0)
        longs = [b["box"]["saved_attribute_attributes"]["valueof"]["parameter_longname"]
                 for b in P.boxes if "saved_attribute_attributes" in b["box"]]
        assert len(set(longs)) == len(longs), "duplicate parameter names"
        n = self.js_name
        return patcher_dict(P.boxes, P.lines, [60.0, 80.0, 1400.0, 900.0], extra={
            "devicewidth": float(width),
            "dependency_cache": [{"name": n, "bootpath": ".", "patcherrelativepath": ".", "type": "TEXT",
                                  "implicit": 1}],
            "project": {
                "version": 1, "creationdate": 3814000000, "modificationdate": 3814000000,
                "viewrect": [0.0, 0.0, 300.0, 500.0], "autoorganize": 1, "hideprojectwindow": 1,
                "showdependencies": 1, "autolocalize": 0,
                "contents": {"patchers": {}, "code": {n: {"kind": "javascript", "local": 1}}},
                "layout": {}, "searchpath": {}, "detailsvisible": 0,
                "amxdtype": 1835887981,                # 'mmmm': a MIDI effect
                "readonly": 0, "devpathtype": 0, "devpath": ".", "sortmode": 0,
                "viewmode": 0, "includepackages": 0},
            "latency": 0, "is_mpe": 0, "minimum_live_version": "",
            "minimum_max_version": "", "platform_compatibility": 0, "autosave": 0})


def mutator():
    d = Device("mutator", "Mutator")
    P = d.P
    hold = toggle(P, "Hold", "Hold", "HOLD", [310, 116, 100, 24], fontsize=13.0)
    d.value(hold, "hold")
    label(P, "no changes", [310, 142, 100, 18], size=11.0)
    label(P, "Change every (bars)", [416, 4, 150, 18])
    ev = tab(P, "Every", "Every", ["1", "2", "4", "8", "16"], 1, [416, 22, 150, 22])
    d.value(ev, "everyset")
    label(P, "Allowed changes", [416, 48, 150, 18])
    for i, (long, text, msg) in enumerate([("Rotate", "ROTATE", "rotate"), ("Drop", "DROP", "drop"),
                                           ("Shift", "SHIFT", "shift"), ("Add", "ADD", "add")]):
        t = toggle(P, long, long, text, [416 + 76 * (i % 2), 66 + 24 * (i // 2), 72, 21], dflt=1)
        d.value(t, msg)
    now = button(P, "Change now", "Now", "NOW", [416, 118, 46, 26], fontsize=12.0)
    d.press(now, "now")
    rev = button(P, "Revert", "Revert", "REVERT", [466, 118, 56, 26], fontsize=12.0)
    d.press(rev, "revert")
    keep = button(P, "Keep", "Keep", "KEEP", [526, 118, 40, 26], fontsize=12.0)
    d.press(keep, "keep")
    label(P, "back to yours / keep this", [416, 146, 150, 18], size=10.0)
    return d, d.finish(572)


def euclid():
    d = Device("euclid", "Euclid Morph")
    P = d.P
    mo = dial(P, "Morph", "Morph", 0.0, 100.0, 0.0, 5, [420, 2, 64, 70])
    d.value(mo, "morph")
    hi = dial(P, "Hits", "Hits", -8, 8, 0, 0, [490, 2, 40, 52])
    d.value(hi, "hits")
    tu = dial(P, "Turn", "Turn", -8, 8, 0, 0, [532, 2, 40, 52])
    d.value(tu, "turn")
    label(P, "0% = yours, 100% = even", [416, 74, 156, 18], size=11.0)
    label(P, "Lanes", [416, 94, 156, 18])
    la = tab(P, "Lanes", "Lanes", ["each note", "together"], 0, [416, 112, 156, 24])
    d.value(la, "lanes")
    label(P, "together: for melodies", [416, 140, 156, 18], size=10.0)
    return d, d.finish(578)


def markov():
    d = Device("markov", "Markov Remix")
    P = d.P
    st = dial(P, "Strictness", "Strict", 0.0, 100.0, 60.0, 5, [420, 0, 64, 68])
    d.value(st, "strictness")
    label(P, "100% = yours", [486, 20, 86, 18], size=11.0)
    label(P, "0% = wild", [486, 38, 86, 18], size=11.0)
    label(P, "New remix every (bars)", [416, 72, 160, 18], size=11.5)
    ne = tab(P, "New every", "Every", ["1", "2", "4", "8", "never"], 0, [416, 92, 160, 22], fontsize=11.0)
    d.value(ne, "newevery")
    nw = button(P, "New remix", "New", "NEW", [416, 118, 52, 26], fontsize=13.0)
    d.press(nw, "newbar")
    og = toggle(P, "Original", "Orig", "ORIGINAL", [472, 118, 104, 26], fontsize=12.0)
    d.value(og, "original")
    km = tab(P, "Mode", "Mode", ["kit", "lanes"], 0, [310, 118, 100, 26], fontsize=12.0)
    d.value(km, "kitmode")
    label(P, "remix by", [310, 146, 100, 18], size=10.0)
    return d, d.finish(582)


def amxd_bytes(patcher):
    body = json.dumps({"patcher": patcher}, indent=1, ensure_ascii=False).encode("utf-8") + b"\n\x00"
    out = b"ampf" + struct.pack("<I", 4) + b"mmmm"   # mmmm = MIDI effect
    out += b"meta" + struct.pack("<I", 4) + b"\x00\x00\x00\x00"
    out += b"ptch" + struct.pack("<I", len(body)) + body
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        if f.endswith(".js"):
            os.remove(os.path.join(OUT, f))
    for make, name in [(mutator, "Mutator"), (euclid, "EuclidMorph"), (markov, "MarkovRemix")]:
        d, patcher = make()
        with open(os.path.join(OUT, name + ".amxd"), "wb") as f:
            f.write(amxd_bytes(patcher))
        with open(os.path.join(OUT, name + ".maxpat"), "w") as f:
            json.dump({"patcher": patcher}, f, indent=1, ensure_ascii=False)
        with open(os.path.join(OUT, d.js_name), "w") as f:
            f.write(d.js_code)
        print("built dist/%s.amxd + %s" % (name, d.js_name))


if __name__ == "__main__":
    main()
